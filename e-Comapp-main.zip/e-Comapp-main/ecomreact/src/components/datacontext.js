import { createContext } from "react";
// defining the context with initial value
export const DataContext = createContext(null);